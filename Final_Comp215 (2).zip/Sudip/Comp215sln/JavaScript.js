﻿$(document).ready(function () {
    //  This loads incidents from local storage when the page loads
    loadIncidentsFromLocalStorage();

    //  This is the Form submission handler to prevent default form submission and  to handle data manually
    $('#incidentForm').submit(function (event) {
        event.preventDefault(); //  It prevents the default form submission action
        if (!this.checkValidity()) {
            // If form fields does not satisfies the constraints,  then  it exits the function
            return;
        }

        var workDoneId = Date.now();  //  This generates a unique ID based on the current timestamp
        var incident = {
            id: workDoneId,
            technicianName: $('#technicianName').val(), // It  Collects technician name input
            workCategory: $('#workCategory').val(), // It  Collects selected work category
            workDescription: $('#workDescription').val(), //It  Collects work description
            timeSpent: parseFloat($('#timeSpent').val()), //It  Collects and converts time spent to float
            outcome: $('#outcome').val() //  It Collects outcome of the work done
        };

        addIncidentToLog(incident); //  This adds the incident to the HTML table
        saveIncidentToLocalStorage(incident); //  And Saves the incident to local storage
        resetForm(); // After the submission it resets the form fields..
    });

    //  This part of code adds a row to the HTML table showing all  the incident details
    function addIncidentToLog(incident) {
        var rowHtml = `<tr id="incident-${incident.id}">
            <td>${incident.technicianName}</td>
            <td>${incident.workCategory}</td>
            <td>${incident.workDescription}</td>
            <td>${incident.timeSpent}</td>
            <td>${incident.outcome}</td>
            <td><button class="btn btn-danger delete-button">Delete</button></td>
        </tr>`;
        $('table tbody').append(rowHtml); //  It adds  the new row to the table body
        updateTotalHours(); //  Again it updates the total hours after adding a new incident
    }

    //  This is the event handler for delete buttons 
    $('table').on('click', '.delete-button', function () {
        var row = $(this).closest('tr'); //  It finds the nearest table row to the button clicked
        var id = row.attr('id').split('-')[1]; //  It extracts all  the unique IDs of the incident
        removeIncident(id); // It  removes the incident from local storage
        row.remove(); // It  removes the row from the table
        updateTotalHours(); // Again calculates total hours after a row is removed
    });

    // Saves the array of incidents to local storage
    function saveIncidentToLocalStorage(incident) {
        var incidents = JSON.parse(localStorage.getItem('incidents')) || []; //  Creating  an empty array
        incidents.push(incident); // Adds the new incident to the array
        localStorage.setItem('incidents', JSON.stringify(incidents)); //  then after it saves the updated array back to local storage
    }

    // Bringing back all  incidents from local storage and adds each to the log
    function loadIncidentsFromLocalStorage() {
        var incidents = JSON.parse(localStorage.getItem('incidents')) || []; // initializes an empty array
        incidents.forEach(addIncidentToLog); // Adds each incident to the HTML table
    }

    //  It Removes a specific incident by ID from local storage
    function removeIncident(id) {
        var incidents = JSON.parse(localStorage.getItem('incidents')) || []; // Retrieves the current array of incidents
        incidents = incidents.filter(incident => incident.id !== parseInt(id)); // Filters out the incident to be removed
        localStorage.setItem('incidents', JSON.stringify(incidents)); // Saves the updated array to local storage
    }

    // Clears all incidents from the log and local storage
    function clearLog() {
        localStorage.removeItem('incidents'); // Clears the incidents from local storage
        $('table tbody').empty(); // Empties the table body
        updateTotalHours(); // Updates the total hours displayed to zero
    }

    // Attaches the clear log function to the clear button
    $('.btn-warning').on('click', clearLog);

    // Resets the form fields to empty after submitting the form
    function resetForm() {
        $('#incidentForm').find('input, textarea').val(''); // Clears all input and textarea fields
    }

    // Updates the total hours displayed at the bottom of the table
    function updateTotalHours() {
        var total = 0;
        $('table tbody tr').each(function () {
            total += parseFloat($(this).find('td:eq(3)').text()); // Sums up the time spent from each row
        });
        $('#totalHours').text(total.toFixed(2)); // Displays the total hours, formatted to two decimal places
    }
});
